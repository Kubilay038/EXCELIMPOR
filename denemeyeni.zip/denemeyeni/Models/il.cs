﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace denemeyeni.Models
{
    public class il
    {
        public int Kodu { get; set; }
        public string Adi { get; set; }
    }
}