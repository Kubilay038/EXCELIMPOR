﻿using denemeyeni.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;


namespace denemeyeni
{
    public class ExcelContext : DbContext
    {

        public ExcelContext() : base("ConString")
        {

        }
        public DbSet<il> ils { get; set; }
        public DbSet<ilce> ilces { get; set; }
        public DbSet<Mahalle> Mahalles { get; set; }
        public DbSet<semt> semts { get; set; }
        public DbSet<PK> PKs { get; set; }
    }
}